export default function Admin() {
  return (
    <div style={{ padding: 40 }}>
      <h1>ADMIN PANEL</h1>
      <p>Acceso protegido (implementar auth con env)</p>
    </div>
  )
}
